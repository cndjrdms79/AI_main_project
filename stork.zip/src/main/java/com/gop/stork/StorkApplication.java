package com.gop.stork;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StorkApplication {

	public static void main(String[] args) {
		SpringApplication.run(StorkApplication.class, args);
	}

}
